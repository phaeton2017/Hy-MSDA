# import os
# from PIL import Image
# import numpy as np
#
# path = "/media/xk/新加卷/wwxdata/segmentation/EvLab-SSBenchmarkPatches/image"
# file_name_list = os.listdir(path)
#
# with open('/media/xk/新加卷/wwxdata/segmentation/EvLab-SSBenchmarkPatches/train.txt', 'w') as f:
#     for file_name in file_name_list:
#         if ".png" in file_name:
#             print(file_name)
#             f.write(file_name + '\n')  # -5表示从后往前数，到小数点位置

import random

def split_file(input_file, output_file1, output_file2, split_ratio):
    with open(input_file, 'r') as f:
        lines = f.readlines()

    random.shuffle(lines)

    split_idx = int(len(lines) * split_ratio)

    with open(output_file1, 'w') as f1:
        for line in lines[:split_idx]:
            f1.write(line)

    with open(output_file2, 'w') as f2:
        for line in lines[split_idx:]:
            f2.write(line)

# 按照 70% 和 30% 的比例将 input.txt 分成两个文件 output1.txt 和 output2.txt
split_file("/media/xk/新加卷/wwxdata/segmentation/EvLab-SSBenchmarkPatches/train.txt", "/media/xk/新加卷/wwxdata/segmentation/EvLab-SSBenchmarkPatches/train_1.txt", "/media/xk/新加卷/wwxdata/segmentation/EvLab-SSBenchmarkPatches/test.txt", 0.7)