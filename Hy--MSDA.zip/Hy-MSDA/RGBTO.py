import os

import torch
import numpy as np
from PIL import Image

# 给定的RGB像素值
label_colors = [(255, 0, 0), (255, 255, 0), (192, 192, 0), (0, 255, 0), (128, 128, 128), (0, 0, 255)]

# 创建一个映射字典，将RGB值映射到类别值
color_to_class = {(255, 0, 0): 0, (255, 255, 0): 1, (192, 192, 0): 2, (0, 255, 0): 2, (128, 128, 128): 2, (0, 0, 255): 2}

# 标签图片的RGB像素值
# label_image = np.array([[[255, 0, 0], [0, 0, 255], [255, 255, 255]],
#                          [[255, 255, 255], [255, 0, 0], [0, 0, 255]]])
input_folder = '/media/xk/新加卷/wwxdata/segmentation/WHDLD/Labels'
output_folder = '/media/xk/新加卷/wwxdata/segmentation/WHDLD/Labels_01'
for file_name in os.listdir(input_folder):
    file_path = os.path.join(input_folder, file_name)
    label_image = Image.open(file_path)
    label_image = np.array(label_image)
    # 初始化单通道标签图片
    label_image_single_channel = np.zeros((label_image.shape[0], label_image.shape[1]))

    # 将RGB像素值转换为类别值
    for i in range(len(label_colors)):
        label_image_single_channel[np.all(label_image == label_colors[i], axis=-1)] = color_to_class[label_colors[i]]

    # 转换为PyTorch Tensor
    # label_image_single_channel = torch.from_numpy(label_image_single_channel).long()
    label_image_single_channel = Image.fromarray(np.uint8(label_image_single_channel))
    label_image_single_channel = label_image_single_channel.save(os.path.join(output_folder, f"{file_name}"))
    # 打印结果
    # print(label_image_single_channel)
    print(file_name)

# import os
# from PIL import Image
# import torch
# import numpy as np
#
# # 定义文件夹路径
# input_folder = '/media/xk/新加卷/wwxdata/segmentation/EvLab-SSBenchmarkPatches/valLabel'
# output_folder = '/media/xk/新加卷/wwxdata/segmentation/EvLab-SSBenchmarkPatches/valLabel_012'
#
# # 确保输出文件夹存在
# os.makedirs(output_folder, exist_ok=True)
#
# # 定义像素值映射关系
# pixel_mapping = {5: 0, 6: 1}
#
# # 遍历文件夹下的所有图片文件
# for filename in os.listdir(input_folder):
#     if filename.endswith(".png"):  # 假设图片格式为png
#         # 打开图像文件
#         img_path = os.path.join(input_folder, filename)
#         img = Image.open(img_path)
#
#         # 将图像转换为PyTorch张量
#         img_tensor = torch.from_numpy(np.array(img))
#
#         # 根据像素值映射进行处理
#         processed_img = torch.zeros_like(img_tensor, dtype=torch.uint8) + 2  # 初始化为2
#         for k, v in pixel_mapping.items():
#             processed_img[img_tensor == k] = v
#
#         # 保存处理后的图像
#         output_path = os.path.join(output_folder, filename)
#         Image.fromarray(processed_img.numpy()).save(output_path)
#         print(filename)