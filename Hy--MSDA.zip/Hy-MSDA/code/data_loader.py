from torchvision import datasets, transforms
import torch

def load_training(root_path, source):
    transform = transforms.Compose(
        [transforms.Resize([256, 256]),
         # transforms.RandomCrop(224),
         transforms.RandomHorizontalFlip(),
         transforms.ToTensor()])
    data = datasets.ImageFolder(root=root_path + r'\gf', transform=transform)
    if source==1:
        data = datasets.ImageFolder(root=root_path + '/gf', transform=transform)
    if source==2:
        data = datasets.ImageFolder(root=root_path + '/landsat', transform=transform)
    if source==3:
        data = datasets.ImageFolder(root=root_path + '/sentinel', transform=transform)
    images=[]
    labels=[]
    for i in range(len(data.imgs)):
        images.append(data.imgs[i][0])
        labels.append(data.imgs[i][1])
    sample = {'image': images, 'mask': labels}
    # train_loader = torch.utils.data.DataLoader(data, batch_size=batch_size, shuffle=True, drop_last=True, **kwargs)
    return sample

def load_testing(root_path, dir, batch_size, kwargs):
    transform = transforms.Compose(
        [transforms.Resize([224, 224]),
         transforms.ToTensor()])
    data = datasets.ImageFolder(root=root_path + dir, transform=transform)
    # test_loader = torch.utils.data.DataLoader(data, batch_size=batch_size, shuffle=True, **kwargs)
    return data
root_path=r'C:\Users\WWX\Desktop\ICL-main\ICL-main\figs'
sample=load_training(root_path,1)

print(sample)