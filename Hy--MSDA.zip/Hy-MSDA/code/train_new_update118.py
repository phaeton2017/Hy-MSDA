import argparse
import logging
import os
import random

import adabound
import bitsandbytes
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import torch.optim as optim
from PIL import Image
from sklearn import metrics
from tensorboardX import SummaryWriter
from torch import nn, argmax
from torch.autograd import Variable
from torch.nn.modules.loss import CrossEntropyLoss
from torch.utils import data
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.transforms import Resize
from tqdm import tqdm
from collections import OrderedDict
import torch.nn.functional as F
from data_loader_SPARCS_ORI import CloudDataset, ToTensorNorm
from utils import mmd
from dataloaders.dataset import BaseDataSets, RandomGenerator, TwoStreamBatchSampler
from networks.net_factory import net_factory
from utils import losses, visualization
from val_2D import test_single_volume_ours
from utils.visualization import subplotimg
import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:20480"
import warnings
warnings.filterwarnings("ignore")

def get_log(file_name):
    logger = logging.getLogger('val')  # 设定logger的名字
    logger.setLevel(logging.INFO)  # 设定logger得等级

    ch = logging.StreamHandler()  # 输出流的hander，用与设定logger的各种信息
    ch.setLevel(logging.INFO)  # 设定输出hander的level

    fh = logging.FileHandler(file_name, mode='a')  # 文件流的hander，输出得文件名称，以及mode设置为覆盖模式
    fh.setLevel(logging.INFO)  # 设定文件hander得lever

    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)  # 两个hander设置个是，输出得信息包括，时间，信息得等级，以及message
    fh.setFormatter(formatter)
    logger.addHandler(fh)  # 将两个hander添加到我们声明的logger中去
    logger.addHandler(ch)
    return logger
parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str,
                    default='../data/ACDC', help='Name of Experiment')
parser.add_argument('--exp', type=str,
                    default='ACDC/Inherent_Consistent_Learning', help='experiment_name')
parser.add_argument('--model', type=str,
                    default='icl_unet', help='model_name')
parser.add_argument('--num_classes', type=int,  default=2,
                    help='output channel of network')
parser.add_argument('--max_iterations', type=int,
                    default=30000, help='maximum epoch number to train')
parser.add_argument('--batch_size', type=int, default=6,
                    help='batch_size per gpu')
parser.add_argument('--deterministic', type=int,  default=1,
                    help='whether use deterministic training')
parser.add_argument('--base_lr', type=float,  default=0.0001,
                    help='segmentation network learning rate')
parser.add_argument('--patch_size', type=list,  default=[256, 256],
                    help='patch size of network Winput')
parser.add_argument('--seed', type=int,  default=1337, help='random seed')
parser.add_argument('--labeled_num', type=int, default=50,
                    help='labeled data')
parser.add_argument('--num_tries', type=str,  default='1',
                    help='number of experiments tryings')

parser.add_argument('--labeled_bs', type=int, default=8,
                    help='labeled_batch_size per gpu')
args = parser.parse_args()


def patients_to_slices(dataset, patiens_num):
    ref_dict = None
    if "ACDC" in dataset:
        ref_dict = {"3": 68, "7": 136,
                    "14": 256, "21": 396, "28": 512, "35": 664, "140": 1312}
    elif "Prostate":
        ref_dict = {"2": 27, "4": 53, "8": 120,
                    "12": 179, "16": 256, "21": 312, "42": 623}
    else:
        print("Error")
    # print(patiens_num)
    # return ref_dict[str(patiens_num)]
    return 256
def test_single_volume(net, i_iter):
    # h5f = h5py.File(FLAGS.root_path + "/volumes/{}.h5".format(case), 'r')
    # image = h5f['image'][:]
    # label = h5f['label'][:]
    ACC = 0;
    Precision = 0;
    Recall = 0;
    F1 = 0
    val_dataset = CloudDataset(domain_name='Landsat8',
                               transform=transforms.Compose([
                                   ToTensorNorm(),
                                   # RandomHorizontallyFlip(),
                               ]), test_mode=1)
    valloader = data.DataLoader(val_dataset,
                                batch_size=1, shuffle=False, num_workers=0, pin_memory=True)
    valloader_iter = iter(valloader)

    iterator = tqdm(range(len(val_dataset)), ncols=70)
    # # for i_iter in range(start_iter, args.num_steps + 1):
    for iter_num in iterator:

        try:
            batch4 = next(valloader_iter)
        except:
            valloader_iter = iter(valloader)
            batch4 = next(valloader_iter)

        image_target, labels_target = batch4['image'], batch4['mask']
        image = image_target.cuda()
        label = labels_target.cuda()

        # prediction = np.zeros_like(label.cpu())
        # for ind in range(image.shape[0]):
        # slice = image[ind, :, :]
        # x, y = slice.shape[0], slice.shape[1]
        # slice = zoom(slice, (patch_size[0] / x, patch_size[1] / y), order=0)
        input = image.float().cuda()
        with torch.no_grad():
            out_main1, out_main2 = net(input, input, input, inference=True)
        out = (out_main1[0] + out_main2[0]) / 2
        out = torch.sigmoid(out).argmax(axis=1)
        # out = torch.argmax(out, dim=1).squeeze(0)
        out = out.cpu().detach().numpy()
        accpred_avg = out.flatten()
        truet = label.detach().cpu().numpy().flatten()
        # print(out.shape, label)
        recall_scoret = metrics.recall_score(truet, accpred_avg, average='macro')  # 召回率
        pre_scoret = metrics.precision_score(truet, accpred_avg, average='macro')  # 准确率
        f1_scoret = metrics.f1_score(truet, accpred_avg, average='macro')
        ACCt = metrics.accuracy_score(truet, accpred_avg)  # 准确度ACC

        ACC = ACCt + ACC
        Recall = recall_scoret + Recall
        Precision = Precision + pre_scoret
        F1 = F1 + f1_scoret
        # print(ACCt)
        # val_str = (
        #             'iteration %d : ACC: %f,Recall: %f, Precision: %f, F1: %f' %
        #             (iter_num/len(val_dataset), ACC/len(val_dataset), Recall/len(val_dataset), Precision/len(val_dataset), F1/len(val_dataset)))
        # logging.info(val_str)
    iterator.close()
    test_str = (
            'iteration %s : ACC: %f,Precision: %f, Recall: %f, F1: %f' %
            (i_iter, ACC / len(val_dataset), Precision / len(val_dataset), Recall / len(val_dataset), F1 / len(val_dataset)))

    # logging = get_log(
    #     '/media/xk/新加卷/code/WWXcode/ICL-main/ICL-main/experiments/ACDC/Inherent_Consistent_Learning_50_labeled/icl_unet_exp_1/test' + '/log.txt')
    logging.info(test_str)
    # return [ACC / len(val_dataset), Precision / len(val_dataset), Recall / len(val_dataset), F1 / len(val_dataset)]

def train(args, snapshot_path):
    base_lr = args.base_lr
    num_classes = args.num_classes
    batch_size = args.batch_size
    max_iterations = args.max_iterations

    # labeled_slice = patients_to_slices(args.r000011ot_path, args.labeled_num)

    model = net_factory(net_type=args.model, in_chns=3, class_num=num_classes)
    # model2 = net_factory(net_type=args.model, in_chns=3, class_num=num_classes)
    # db_train = BaseDataSets(base_dir=args.root_path, split="train", num=None, transform=transforms.Compose([
    #     RandomGenerator(args.patch_size)
    # ]))
    # db_val = BaseDataSets(base_dir=args.root_path, split="val_test")
    train_dataset1 = CloudDataset(domain_name='GF-2',
                                  transform=transforms.Compose([
                                      ToTensorNorm(),
                                      # RandomHorizontallyFlip(),
                                  ]), test_mode=0)
    train_dataset2 = CloudDataset(domain_name='sentinel-2',
                                  transform=transforms.Compose([
                                      ToTensorNorm(),
                                      # RandomHorizontallyFlip(),
                                  ]), test_mode=0)

    train_dataset3 = CloudDataset(domain_name='Landsat8',
                                  transform=transforms.Compose([
                                      ToTensorNorm(),
                                      # RandomHorizontallyFlip(),
                                  ]), test_mode=0)

    val_dataset = CloudDataset(domain_name='Landsat8',
                                  transform=transforms.Compose([
                                      ToTensorNorm(),
                                      # RandomHorizontallyFlip(),
                                  ]), test_mode=1)

    train_dataset1_size = len(train_dataset1)
    print('source size1: ', train_dataset1_size)

    train_dataset2_size = len(train_dataset2)
    print('source size2: ', train_dataset2_size)

    train_dataset3_size = len(train_dataset3)
    print('target size: ', train_dataset3_size)

    val_dataset_size = len(val_dataset)
    print('val size: ', val_dataset_size)

    trainloader1 = data.DataLoader(train_dataset1,
                                   batch_size=args.batch_size, shuffle=True, num_workers=0, pin_memory=True)

    trainloader2 = data.DataLoader(train_dataset2,
                                   batch_size=args.batch_size, shuffle=True, num_workers=0, pin_memory=True)

    trainloader3 = data.DataLoader(train_dataset3,
                                   batch_size=args.batch_size, shuffle=True, num_workers=0, pin_memory=True)

    valloader = data.DataLoader(val_dataset,
                                batch_size=1, shuffle=False, num_workers=0, pin_memory=True)

    trainloader1_iter = iter(trainloader1)
    trainloader2_iter = iter(trainloader2)
    trainloader3_iter = iter(trainloader3)
    valloader_iter = iter(valloader)

    def worker_init_fn(worker_id):
        random.seed(args.seed + worker_id)

    
    model.train()
    # model2.train()
    # optimizer = optim.SGD(model.parameters(), lr=base_lr,
    #                       momentum=0.9, weight_decay=0.0001)
    # optimizer = adabound.AdaBound(model.parameters(), lr=base_lr, final_lr=0.1)
    optimizer = bitsandbytes.optim.AdamW8bit(model.parameters(), lr=base_lr, betas=(0.9, 0.995))
    optimizer = bitsandbytes.optim.AdamW(model.parameters(), lr=base_lr, betas=(0.9, 0.995), optim_bits=8)

    ce_loss = CrossEntropyLoss()
    dice_loss = losses.DiceLoss(num_classes)
    aux_loss = losses.AuxLoss(num_classes, resize=args.patch_size)
    pse_loss = losses.PseudoSoftLoss(num_classes, resize=args.patch_size)
    
    writer = SummaryWriter(snapshot_path + '/log')
    logging.info("{} iterations per epoch".format(len(trainloader1)))

    iter_num = 0
    # max_epoch = max_iterations // len(trainloader1) + 1
    max_epoch = 30000
    print(max_epoch)
    best_performance = 0.0
    iterator = tqdm(range(max_epoch), ncols=70)
    # for i_iter in range(start_iter, args.num_steps + 1):
    for iter_num in iterator:
    # for i_iter in range(start_iter, args.num_steps + 1):
        try:
            batch1 = next(trainloader1_iter)
        except:
            trainloader1_iter = iter(trainloader1)
            batch1 = next(trainloader1_iter)

        try:
            batch2 = next(trainloader2_iter)
        except:
            trainloader2_iter = iter(trainloader2)
            batch2 = next(trainloader2_iter)

        try:
            batch3 = next(trainloader3_iter)
        except:
            trainloader3_iter = iter(trainloader3)
            batch3 = next(trainloader3_iter)

        images1, labels1 = batch1['image'], batch1['mask']
        images2, labels2 = batch2['image'], batch2['mask']
        images3, labels3 = batch3['image'], batch3['mask']
        images1, images2, image3 = images1.cuda(), images2.cuda(), images3.cuda()
        labels1, labels2, labels3 = labels1.cuda(), labels2.cuda(), labels3.cuda()
        images1 = Variable(images1, requires_grad=True);labels1 = Variable(labels1, requires_grad=True)
        images2 = Variable(images2, requires_grad=True);labels2 = Variable(labels2, requires_grad=True)
        images3 = Variable(images3, requires_grad=True);labels3 = Variable(labels3, requires_grad=True)


        outputs1, outputs2 = model(images1, images2, images3)
        # outputs1 = model(images1, images3)
        # outputs2 = model(images2, images3)
        # print(outputs1[0], labels1.long())
        # exit() return output_lab, output_unlab, feat_Maps_lab, feat_Maps_unlab, feat_Maps_consisunlab
        loss_ce1 = ce_loss(torch.sigmoid(outputs1[0]), labels1.long())
        # loss_aux1 = aux_loss(outputs1[2], labels1)

        loss_pse1 = pse_loss(outputs1[5], outputs1[2])
        loss_aux_consis1 = losses.softmax_mse_loss(outputs1[5], outputs1[6])

        eps = 1e-8
        cross_entropy = nn.CrossEntropyLoss(reduction='mean')

        y_src_clf1 = outputs1[0].max(1)[1]
        y_tgt_clf1 = outputs1[2].max(1)[1]

        # eq (28)
        # loss_clf1 = cross_entropy(outputs1[0], labels1.long())
        loss_src_adv1 = cross_entropy(outputs1[1], y_src_clf1)

        # eq (29)
        p_tgt_adv1 = F.softmax(outputs1[3], dim=1)
        logloss_tgt1 = torch.log(1 - p_tgt_adv1 + eps)
        loss_tgt_adv1 = F.nll_loss(logloss_tgt1, y_tgt_clf1)

        # eq (30)
        loss_transfer1 = (0.08 * loss_src_adv1) + loss_tgt_adv1

        # final loss
        loss_combined1 = loss_transfer1

        # loss_clf1 = ce_loss(torch.sigmoid(outputs1[0]), labels1.long())
        # loss_src_adv1 = ce_loss(torch.sigmoid(outputs1[1]), torch.sigmoid(outputs1[0]))
        # p_tgt_adv = F.softmax(outputs1[3], dim=1)
        # logloss_tgt = torch.log(1 - p_tgt_adv + eps)
        # loss_tgt_adv = F.nll_loss(logloss_tgt, y_tgt_clf)

        loss1 = loss_ce1 + loss_pse1 + 50*loss_aux_consis1 + loss_combined1

        loss_ce2 = ce_loss(torch.sigmoid(outputs2[0]), labels2.long())
        # loss_aux2 = aux_loss(outputs2[2], labels2)

        loss_pse2 = pse_loss(outputs2[5], outputs2[2])
        loss_aux_consis2 = losses.softmax_mse_loss(outputs2[5], outputs2[6])

        y_src_clf2 = outputs2[0].max(1)[1]
        y_tgt_clf2 = outputs2[2].max(1)[1]

        # eq (28)
        # loss_clf2 = cross_entropy(outputs2[0], labels1.long())
        loss_src_adv2 = cross_entropy(outputs2[1], y_src_clf2)

        # eq (29)
        p_tgt_adv2 = F.softmax(outputs2[3], dim=1)
        logloss_tgt2 = torch.log(1 - p_tgt_adv2 + eps)
        loss_tgt_adv2 = F.nll_loss(logloss_tgt2, y_tgt_clf2)

        # eq (30)
        loss_transfer2 = (0.08 * loss_src_adv2) + loss_tgt_adv2

        # final loss
        loss_combined2 = loss_transfer2

        loss2 = loss_ce2 + loss_pse2 + 50*loss_aux_consis2 + loss_combined2
        # source1 = outputs1[5][4].view(outputs1[5][4].size(0), -1)
        # source2 = outputs2[5][4].view(outputs2[5][4].size(0), -1)
        # target1 = outputs1[6][4].view(outputs1[6][4].size(0), -1)
        # target2 = outputs2[6][4].view(outputs2[6][4].size(0), -1)
        # mmd_loss1 = mmd.mmd(source1, target1)
        # mmd_loss2 = mmd.mmd(source2, target2)
        consistency_loss = F.mse_loss(outputs1[2],outputs2[2])


        # loss_cls = nn.BCELoss()
        # outputs1[7] = torch.argmax(outputs1[7], dim=1)
        # print(outputs1[7].squeeze().shape, domain_lab1.shape)
        # exit()
        # loss_cls1 = loss_cls(torch.sigmoid(outputs1[7]), domain_lab1.float())
        # loss_cls2 = loss_cls(torch.sigmoid(outputs2[7]), domain_lab2.float())
        # loss = loss_ce1 #+ loss_ce2
        loss = loss1 + loss2 + consistency_loss
        optimizer.zero_grad()
        # optimizer2.zero_grad()
        loss.backward()
        optimizer.step()
        # optimizer2.step()

    #metrics:

        outputs1_acc = torch.sigmoid(outputs1[0]).argmax(axis=1)
        pred1 = outputs1_acc.cpu().numpy().flatten()
        true1 = labels1.detach().cpu().numpy().flatten()

        recall_score1 = metrics.recall_score(true1, pred1, average='macro')  # 召回率
        pre_score1 = metrics.precision_score(true1, pred1, average='macro')  # 准确率
        f1_score1 = metrics.f1_score(true1, pred1, average='macro')
        ACC1 = metrics.accuracy_score(true1, pred1)  # 准确度ACC

        outputs2_acc = torch.sigmoid(outputs2[0]).argmax(axis = 1)
        pred2 = outputs2_acc.cpu().numpy().flatten()
        true2 = labels2.detach().cpu().numpy().flatten()

        recall_score2 = metrics.recall_score(true2, pred2, average='macro')  # 召回率
        pre_score2 = metrics.precision_score(true2, pred2, average='macro')  # 准确率
        f1_score2 = metrics.f1_score(true2, pred2, average='macro')
        ACC2 = metrics.accuracy_score(true2, pred2)  # 准确度ACC

        outputst_acc1 = torch.sigmoid(outputs1[2]).argmax(axis=1)
        predt1 = outputst_acc1.cpu().numpy().flatten()
        truet = labels3.detach().cpu().numpy().flatten()

        recall_scoret1 = metrics.recall_score(truet, predt1, average='macro')  # 召回率
        pre_scoret1 = metrics.precision_score(truet, predt1, average='macro')  # 准确率
        f1_scoret1 = metrics.f1_score(truet, predt1, average='macro')
        ACCt1 = metrics.accuracy_score(truet, predt1)  # 准确度ACC

        outputst_acc2 = torch.sigmoid(outputs2[2]).argmax(axis=1)
        predt2 = outputst_acc2.cpu().numpy().flatten()
        # truet2 = labels3.detach().cpu().numpy().flatten()

        recall_scoret2 = metrics.recall_score(truet, predt2, average='macro')  # 召回率
        pre_scoret2 = metrics.precision_score(truet, predt2, average='macro')  # 准确率
        f1_scoret2 = metrics.f1_score(truet, predt2, average='macro')
        ACCt2 = metrics.accuracy_score(truet, predt2)  # 准确度ACC

        # preds1 = (torch.sigmoid(outputs1[1]))
        # preds2 = (torch.sigmoid(outputs2[1]))
        # pred_avg = (preds1 + preds2)/2
        # pred_avg = pred_avg.argmax(axis=1)
        #

        pred_avg = (outputs1[2] + outputs2[2]) / 2
        pred_avg = torch.sigmoid(pred_avg).argmax(axis=1)

        accpred_avg = pred_avg.detach().cpu().numpy().flatten()
        recall_scoret = metrics.recall_score(truet, accpred_avg, average='macro')  # 召回率
        pre_scoret = metrics.precision_score(truet, accpred_avg, average='macro')  # 准确率
        f1_scoret = metrics.f1_score(truet, accpred_avg, average='macro')
        ACCt = metrics.accuracy_score(truet, accpred_avg)  # 准确度ACC

        pred_t1 = outputst_acc1.cpu().numpy(); pred_t2 = outputst_acc2.cpu().numpy()


        for j in range(args.batch_size):
            out_dir = os.path.join(snapshot_path + '/out')
            # out_dir_output = os.path.join(
            #     '../CDnetV2-pytorch-master-main/checkpoints/gf2_csdnetv1/out/output/' + f'{(epoch):04d}')

            os.makedirs(out_dir, exist_ok=True)
            # os.makedirs(out_dir_output, exist_ok=True)
            # print(batch3['name'][j][35:])
            image_t = Image.open('/media/xk/新加卷1/wwxdata/' + batch3['name'][0])
            # image_t = Image.open('/media/xk/新加卷1/wwxdata/clouddata/GF-2/cloud_multi/rgb/' + batch2['name'][j])  # +'.png')
            # imagename = batch2['name'][j]
            # print(os.path.join(out_dir, imagename))
            rows, cols = 1, 5
            from matplotlib import pyplot as plt
            fig, axs = plt.subplots(
                rows,
                cols,
                figsize=(4 * cols, 4 * rows),
            )
            subplotimg(axs[0], np.asarray(image_t), 'Image')
            subplotimg(axs[1],
                       labels3[0],  # gt_semantic_seg[j],
                       'label',
                       cmap='cityscapes')
            subplotimg(axs[2],
                       pred_t1[0],  # gt_semantic_seg[j],
                       'Pred1',
                       cmap='cityscapes')
            subplotimg(axs[3],
                       pred_t2[0],  # gt_semantic_seg[j],
                       'Pred2',
                       cmap='cityscapes')
            subplotimg(axs[4],
                       pred_avg[0],  # gt_semantic_seg[j],
                       'Pred',
                       cmap='cityscapes')
            for ax in axs.flat:
                ax.axis('off')
            plt.savefig(
                os.path.join(out_dir,
                            batch3['name'][0][35:-4] + '_' +str(ACC2)) + '.jpg')
            plt.close()
            # save_output(imagename, targetpred[j], out_dir_output, ACC)
        lr_ = base_lr * (1.0 - iter_num / max_iterations) ** 0.9
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr_

        iter_num = iter_num + 1
        writer.add_scalar('ACC1', ACC1, iter_num)
        writer.add_scalar('pre_score1', pre_score1, iter_num)
        writer.add_scalar('recall_score1', recall_score1, iter_num)
        writer.add_scalar('f1_score1', f1_score1, iter_num)
        writer.add_scalar('ACC2', ACC2, iter_num)
        writer.add_scalar('pre_score2', pre_score2, iter_num)
        writer.add_scalar('recall_score2', recall_score2, iter_num)
        writer.add_scalar('f1_score2', f1_score2, iter_num)
        writer.add_scalar('ACCt', ACCt, iter_num)
        writer.add_scalar('ACCt1', ACCt1, iter_num)
        writer.add_scalar('pre_scoret1', pre_scoret1, iter_num)
        writer.add_scalar('recall_scoret1', recall_scoret1, iter_num)
        writer.add_scalar('f1_scoret1', f1_scoret1, iter_num)
        writer.add_scalar('ACCt2', ACCt2, iter_num)
        writer.add_scalar('pre_scoret2', pre_scoret2, iter_num)
        writer.add_scalar('recall_scoret2', recall_scoret2, iter_num)
        writer.add_scalar('f1_scoret2', f1_scoret2, iter_num)
        writer.add_scalar('Info/lr', lr_, iter_num)
        writer.add_scalar('Loss/loss', loss, iter_num)
        writer.add_scalar('Loss/loss1', loss1, iter_num)
        writer.add_scalar('Loss/loss2', loss2, iter_num)
        # writer.add_scalar('Loss/loss_mmd', loss_mmd, iter_num)
        writer.add_scalar('Loss/loss_combined1', loss_combined1, iter_num)
        writer.add_scalar('Loss/loss_combined2', loss_combined2, iter_num)
        writer.add_scalar('Loss/loss_cons', consistency_loss, iter_num)
        # writer.add_scalar('Loss/loss_seg', loss_seg, iter_num)
        # writer.add_scalar('Loss/loss_aux', loss_aux, iter_num)
        # writer.add_scalar('Loss/loss_pse', loss_pse, iter_num)
        # writer.add_scalar('Loss/loss_aux_consis', 50*loss_aux_consis, iter_num)

        if iter_num % 20 == 0:
        # print('iter={0:5d},l_ce={1:.3f}, l_pred={2:.3f}, l_aux1={3:.3f}, l_aux2={4:.3f}, l_aux3={5:.3f},'.format(i_iter, loss_ce_value, loss_pred_value, loss_aux1_value, loss_aux2_value, loss_aux3_value, loss_aux1_value ))
            train_str = ('iteration %d : loss : %f, loss_1: %f, loss_2: %f, loss_cons: %f, loss_combined1: %f, loss_combined2: %f, accs1: %f, accs2: %f,acct: %f, acct1: %f, acct2: %f' %
            (iter_num, loss.item(), loss1.item(), loss2.item(), consistency_loss.item(), loss_combined1.item(),loss_combined2.item(), ACC1, ACC2, ACCt, ACCt1, ACCt2))
            logging.info(train_str)

        #
        # ACC_val = 0; recall_score_val =0; pre_score_val =0; f1_score_val = 0
        if iter_num % 300 == 0:
            print('Validation ...')
            save_model = os.path.join(snapshot_path + '/model', 'model_' + str(iter_num) + '.pth')
            save_dict = OrderedDict()
            for key, val in model.state_dict().items():
                if not 'sspa' in key and not 'uscl' in key:
                    save_dict.update({key:val})
            torch.save(save_dict, save_model)
            logging.info('saving model at iter {}'.format(iter_num))

            # model.eval()
            test_single_volume(model, iter_num)
        #     iterator2 = tqdm(range(len(valloader)), leave=True, ncols=70)
        #     for iter_t in iterator2:
        #         # for i_iter in range(start_iter, args.num_steps + 1):
        #         try:
        #             batch4 = next(valloader_iter)
        #         except:
        #             valloader_iter = iter(valloader)
        #             batch4 = next(valloader_iter)
        #     # for iter_t, batch4 in enumerate(valloader):
        #
        #         image_target, labels_target = batch4['image'], batch4['mask']
        #         image_target = image_target.cuda()
        #         labels_target = labels_target.cuda()
        #
        #         image_target = Variable(image_target, requires_grad=True);
        #         labels_target = Variable(labels_target, requires_grad=True)
        #
        #         model.eval()
        #         with torch.no_grad():
        #             out1, out2 = model(image_target, image_target, image_target, inference=True)
        #         valpreds1 = (torch.sigmoid(out1[0]))
        #         valpreds2 = (torch.sigmoid(out2[0]))
        #         valpred_avg = (valpreds1 + valpreds2) / 2
        #         valpred_avg = valpred_avg.argmax(axis=1)
        #         # pred_avg = torch.sigmoid(torch.tensor((outputs1[0].detach().cpu().numpy() + outputs2[0].detach().cpu().numpy())/2)).argmax(axis=1)
        #         # pred_avg = pred_avg.cpu().numpy()
        #         acc_val = valpred_avg.detach().cpu().numpy().flatten()
        #         true = labels_target.detach().cpu().numpy().flatten()
        #         recall_score = metrics.recall_score(true, acc_val, average='macro')  # 召回率
        #         pre_score = metrics.precision_score(true, acc_val, average='macro')  # 准确率
        #         f1_score = metrics.f1_score(true, acc_val, average='macro')
        #         accurate = metrics.accuracy_score(true, acc_val)  # 准确度ACC
        #         ACC_val = accurate + ACC_val; recall_score_val = recall_score_val + recall_score
        #         pre_score_val = pre_score_val + pre_score
        #         f1_score_val = f1_score_val + f1_score
        #         val1 = valpreds1.argmax(axis=1).cpu().numpy()
        #         val2 = valpreds2.argmax(axis=1).cpu().numpy()
        #
        #         # for j in range(args.batch_size):
        #         out_dir = os.path.join(snapshot_path + '/val/' + str(iter_num))
        #         # out_dir_output = os.path.join(
        #         #     '../CDnetV2-pytorch-master-main/checkpoints/gf2_csdnetv1/out/output/' + f'{(epoch):04d}')
        #
        #         os.makedirs(out_dir, exist_ok=True)
        #         # os.makedirs(out_dir_output, exist_ok=True)
        #         # print(batch3['name'][j][35:])
        #         # print(batch4['name'])
        #         image = Image.open('/media/xk/新加卷1/wwxdata/' + batch4['name'][0])
        #         # image_t = Image.open('/media/xk/新加卷1/wwxdata/clouddata/GF-2/cloud_multi/rgb/' + batch2['name'][j])  # +'.png')
        #         imagename = batch4['name']
        #         # print(os.path.join(out_dir, imagename))
        #         rows, cols = 1, 5
        #         from matplotlib import pyplot as plt
        #         fig, axs = plt.subplots(
        #             rows,
        #             cols,
        #             figsize=(4 * cols, 4 * rows),
        #         )
        #         subplotimg(axs[0], np.asarray(image), 'Image')
        #         subplotimg(axs[1],
        #                    labels_target,  # gt_semantic_seg[j],
        #                    'label',
        #                    cmap='cityscapes')
        #         subplotimg(axs[2],
        #                    val1,  # gt_semantic_seg[j],
        #                    'Pred1',
        #                    cmap='cityscapes')
        #         subplotimg(axs[3],
        #                    val2,  # gt_semantic_seg[j],
        #                    'Pred2',
        #                    cmap='cityscapes')
        #         subplotimg(axs[4],
        #                    valpred_avg,  # gt_semantic_seg[j],
        #                    'Pred',
        #                    cmap='cityscapes')
        #         for ax in axs.flat:
        #             ax.axis('off')
        #         plt.savefig(
        #             os.path.join(out_dir,
        #                          batch4['name'][0][35:-4] + '.jpg'))
        #         plt.close()
        #
        #             # save_output(imagename, targetpred[j], out_dir_output, ACC)
        #     # print('iter={0:5d},l_ce={1:.3f}, l_pred={2:.3f}, l_aux1={3:.3f}, l_aux2={4:.3f}, l_aux3={5:.3f},'.format(i_iter, loss_ce_value, loss_pred_value, loss_aux1_value, loss_aux2_value, loss_aux3_value, loss_aux1_value ))
        #     val_str = ('iteration %d : acc_val: %f, recall_score_val: %f,pre_score_val: %f, f1_score_val: %f' %
        #         (iter_num, ACC_val/len(val_dataset), recall_score_val/len(val_dataset), pre_score_val/len(val_dataset), f1_score_val/len(val_dataset)))
        #     logging.info(val_str)
        #
        #     writer.add_scalar('ACC_val', ACC_val/len(train_dataset3), iter_num)
        #     iterator2.close()
        #     # saving the best model
        #     if ACC_val/len(train_dataset3) > best_performance:
        #         best_performance = ACC_val/len(train_dataset3)
        #         save_best = os.path.join(snapshot_path+'/model', 'model_best' + str(iter_num) +'.pth')
        # if iter_num % 200 == 0:


    writer.close()
    return "Training Finished!"


if __name__ == "__main__":
    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)

    snapshot_path = "../experiments/{}_{}_labeled/{}_exp_{}".format(
        args.exp, args.labeled_num, args.model, args.num_tries)
    if not os.path.exists(snapshot_path+'/model'):
        os.makedirs(snapshot_path+'/model')

    logging.basicConfig(filename=snapshot_path+"/log117.txt", level=logging.INFO,
                        format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%H:%M:%S')
    # logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.info(str(args))

    logging = get_log(snapshot_path + '/log/log.txt')
    if hasattr(torch.cuda, 'empty_cache'):
        torch.cuda.empty_cache()

    train(args, snapshot_path)
