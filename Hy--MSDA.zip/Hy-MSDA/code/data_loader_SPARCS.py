# data loader
from __future__ import print_function, division
import os
import torch
from PIL import Image
# from skimage import io
import numpy as np
from torch.utils.data import Dataset, DataLoader
from torchvision.transforms import Resize


#from osgeo import gdal

#==========================dataset load==========================
class ToTensorNorm(object):
    """Convert ndarrays in sample to Tensors."""
    def __init__(self):
        pass
    def __call__(self, sample):
        
        image, label = sample['image'], sample['mask']
        
        if (np.max(label) < 1e-6):
            label = label
        else:
            label = label / np.max(label)
        
        if np.max(image) != 0:
            image = image / np.max(image)
        else:
            image = image

        return {'image': torch.from_numpy(image),
                'mask': torch.from_numpy(label)}

class CloudDataset(Dataset):
    def __init__(self, domain_name, transform=None, test_mode=1):
        self.domain_name = domain_name
        self.test_mode = test_mode
        train_txt = []
        if self.domain_name == 'AISD':
            if self.test_mode ==0:
                train_txt = '/media/xk/新加卷1/wwxdata/segmentation/AISD/train.txt'
            else:
                train_txt = '/media/xk/新加卷1/wwxdata/segmentation/AISD/train.txt'
            # train_txt = '/media/xk/新加卷1/wwxdata/segmentation/AISD/train.txt'
        elif self.domain_name == 'WHDLD':
            train_txt = '/media/xk/新加卷1/wwxdata/segmentation/WHDLD/train.txt'
        # train_txt = "/media/xk/新加卷1/wwxdata/cloud_source/train.txt"
        elif self.domain_name == 'EvLab-SSBenchmarkPatches':
            train_txt = '/media/xk/新加卷1/wwxdata/segmentation/EvLab-SSBenchmarkPatches/train.txt'
            # if self.test_mode ==0:
            #     train_txt = '/media/xk/新加卷1/wwxdata/segmentation/EvLab-SSBenchmarkPatches/train.txt'
            # else:
            #     train_txt = '/media/xk/新加卷1/wwxdata/segmentation/EvLab-SSBenchmarkPatches/train.txt'

        with open(train_txt, 'r', encoding='utf-8') as f:
            train_list = f.readlines()
        self.file_name_list = train_list

        # self.label_name_list = lbl_nam
        # e_list
        self.transform = transform
        # self.root = '/media/xk/新加卷1/wwxdata'#'/media/xk/新加卷/code/DAFormer-master/data'r'E:/code/CDnetV2-pytorch-master-main/CDnetV2-pytorch-master-main/data/cloud/

    def __len__(self):
        return len(self.file_name_list)

    def __getitem__(self, idx):

        img_name_add = self.file_name_list[idx][:-1]
        name = self.file_name_list[idx]
        img_name = self.file_name_list[idx]
        img_name = img_name.replace("\n", "")
        label_name = []
        if self.test_mode == 0:
            if self.domain_name == 'AISD':
                label_name = '/media/xk/新加卷1/wwxdata/segmentation/AISD/label_01/' + img_name[:-9] + 'labels.png'
                img_name = '/media/xk/新加卷1/wwxdata/segmentation/AISD/image/' + img_name
                source_lab = 1
            elif self.domain_name == 'WHDLD':
                label_name = '/media/xk/新加卷1/wwxdata/segmentation/WHDLD/label_01/' + img_name[:-4] + '.png'
                img_name = '/media/xk/新加卷1/wwxdata/segmentation/WHDLD/image/' + img_name
                source_lab = 0
            elif self.domain_name == 'EvLab-SSBenchmarkPatches':
                label_name = '/media/xk/新加卷1/wwxdata/segmentation/EvLab-SSBenchmarkPatches/label_01/' + img_name[:-4] + '.png'
                img_name = '/media/xk/新加卷1/wwxdata/segmentation/EvLab-SSBenchmarkPatches/image/' + img_name
                source_lab = 2

        if self.test_mode == 1:
            label_name = '/media/xk/新加卷1/wwxdata/segmentation/AISD/label_01/' + img_name[:-9] + 'labels.png'
            img_name = '/media/xk/新加卷1/wwxdata/segmentation/AISD/image/' + img_name
            # label_name = 'clouddata/' + self.domain_name + '/cloud_multi/label/' + img_name + '.png'
            # img_name = 'clouddata/'+ self.domain_name + '/cloud_multi/rgb/' + img_name + '.png'
        # print(img_name)
        image = Image.open(img_name)
        label = Image.open(label_name).convert("L")
        t_resize = Resize([256,256])
        image = t_resize(image)
        label = t_resize(label)
        image = np.array(image)
        image = image/255.0


        label = np.array(label)
        # label = label.reshape(321, 321, 1)
        # print(label.shape)
        # label = label[np.newaxis, :]
        # label = np.transpose(label, [2,0,1])
        image = np.transpose(image, [2,0,1])
        img_10ch = image.astype(np.float32)
        label_1ch = label.astype(np.float32)
        sample = {'image': img_10ch, 'mask': label_1ch, 'name': img_name}

        return sample
    #rgb/lc.jo